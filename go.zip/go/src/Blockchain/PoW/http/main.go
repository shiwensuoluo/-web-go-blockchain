package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"strconv"
	"strings"
	"sync"
	"time"
)

//设置难度系数，4
const difficulty = 4

//定义区块
type Block struct{
	Index int
	Timestamp string

	BMP int

	//当前区块哈希
	HashCode string

	PreHash string

	Diff int

	Nonce int

}

//用数组维护区块链
var  Blockchain []Block

//声明锁
var mutex = &sync.Mutex{}

//生成区块
func generateBlock(oldBlock Block,BMP int) Block {
	//神明新区块
	var newBlock Block
	newBlock.PreHash = oldBlock.HashCode
	newBlock.Timestamp = time.Now().String()
	newBlock.Index = oldBlock.Index + 1
	newBlock.BMP = BMP
	newBlock.Diff = difficulty
	//循环挖矿
	for i := 0; ;i++ {
		//每挖一次，Nonce+1
		newBlock.Nonce++
		hash := calculateHash(newBlock)
		fmt.Println(hash)

		if isHashValued(hash,newBlock.Diff){

			fmt.Println("挖矿成功")
			newBlock.HashCode=hash

			return newBlock
		}

	}

}

//按照规则，生成hash值
func calculateHash(block Block)string{
	record := strconv.Itoa(block.Index)+block.Timestamp+
		strconv.Itoa(block.Nonce) + strconv.Itoa(block.BMP)
	sha := sha256.New()
	sha.Write([]byte(record))
	hashed := sha.Sum(nil)
	return hex.EncodeToString(hashed)
}

//判断hash值前导0个数和难度系数是否一致
func isHashValued(hash string,difficulty int) bool {
	prefix := strings.Repeat("0", difficulty)
	return strings.HasPrefix(hash,prefix)
}


func main(){
	//测试的代码可行
	//var firstBlock Block
	//firstBlock.Diff = 4
	//firstBlock.Nonce = 0
	//firstBlock.PreHash = "0"
	//firstBlock.BMP = 1
	//firstBlock.Index = 0
	//firstBlock.HashCode = "0"
	//generateBlock(firstBlock,1)



	//基于web去做
	


}