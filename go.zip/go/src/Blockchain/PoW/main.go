package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"strconv"
	"strings"
	"time"
)

//通过代码实现挖矿

//1、声明区块结构体
type Block struct {
	//上一个区块哈希
	PreHash string
	//当前区块哈希
	HashCode string
	//时间戳
	TimeStamp string
	//当前网络难度系数
	//控制哈希值有几个前导0
	Diff int
	//存交易信息
	Data string
	//区块高度
	Index int
	//随机数
	Nonce int
}

//创建创世区块（链中第一个区块）

func GenerateFirstBlock(data string) Block{

	var firstblock  Block
	firstblock.PreHash="0"
	firstblock.TimeStamp = time.Now().String()
	//暂且设置为4，即前导0个数
	firstblock.Diff = 4
	firstblock.Data = data
	firstblock.Index = 1
	firstblock.Nonce = 0

	//当前块哈希
	//用sha256算一个真正的哈希
	firstblock.HashCode = GenerationHashValue(firstblock)
	return firstblock
}

//生成区块的哈希值
func GenerationHashValue(block Block) string{
	var hashdata = strconv.Itoa(block.Index)+strconv.Itoa(block.Nonce)+
		strconv.Itoa(block.Diff)+block.TimeStamp
	//哈希算法
	var sha=sha256.New()
	sha.Write([]byte(hashdata))

    hashed :=sha.Sum(nil)
    //字节转化为字符串
    return hex.EncodeToString(hashed)
}

func main(){

	//创建创世区块
	firstBlock := GenerateFirstBlock("创世区块")
	fmt.Println(firstBlock)
	fmt.Println(firstBlock.Data)

	//产生第二个区块
    GenerateNextBlock("第二个区块",firstBlock)
}

//产生新的区块
 func GenerateNextBlock(data string,oldBlock Block) Block {
 	//产生一个新区块
 	var newBlock Block
 	newBlock.TimeStamp =time.Now().String()
 	//前导0为4个
 	newBlock.Diff = 4
 	//区块高度
 	newBlock.Index = 2
 	newBlock.Data = data
 	newBlock.PreHash = oldBlock.HashCode
 	//0由矿工调整
 	newBlock.Nonce = 0
 	//利用PoW挖矿
 	newBlock.HashCode = pow(newBlock.Diff,&newBlock)
	 return newBlock
 }

//PoW工作量证明算法进行哈希碰撞
//穿指针，保证操作是同一对象
 func pow(diff int,block *Block) string{
 	//不停地去挖矿
 	for{
 		hash :=GenerationHashValue(*block)
 		//每挖一次，打印一次哈希值
 		fmt.Println(hash)
 		//判断hash值前导零是否为4
 		if strings.HasPrefix(hash, strings.Repeat("0",diff)){
 			fmt.Println("挖矿成功")
 			return hash
		}else {
			//没挖到，随机值自增
			block.Nonce++
		}
	}


 }