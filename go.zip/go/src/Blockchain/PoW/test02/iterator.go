package test02

import (
	"fmt"
)

type Iterator interface{
	//判断是否有下一个
	Next() bool
	//遍历键值
	Key() []byte
	Value() []byte
}

//键值结构体
type Pair struct{

	Key []byte
	Value []byte
}
//迭代器结构体
type DefaultIterator struct{
	data []Pair
	index int
	length int
}

func NewDefaultIterator(data map[string][]byte) *DefaultIterator {
	self :=new(DefaultIterator)
	self.index = -1
	self.length = len(data)
	for k,v :=range data{
		p :=Pair{
			Key:[]byte(k),
			Value: v,
		}
		//遍历出的数据添加到data
		self.data = append(self.data,p)
	}
	return self

}

func (self *DefaultIterator)Next() bool {
	//还有值
	if self.index < self.length - 1{
		self.index++
		return true
	}
	return false

}

func (self *DefaultIterator)Key() []byte{
	if self.index== -1||self.index >=self.length{
		panic(fmt.Errorf("IndexOutfBoundError"))
	}
	return self.data[self.index].Key
}

func (self *DefaultIterator)Value() []byte{
	if self.index >=self.length{
		panic(fmt.Errorf("IndexOutfBoundError"))
	}
	return self.data[self.index].Value
}




