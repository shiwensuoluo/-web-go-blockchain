package test02

import (
	"bytes"
	"fmt"
	"testing"
)

func Test_leveldb(t *testing.T) {
	db,err := New("")
	check(err)

	err = db.Put([]byte("k1"),[]byte("v1"))
	check(err)
	err = db.Put([]byte("k4"),[]byte("v4"))
	check(err)
	err = db.Put([]byte("k2"),[]byte("v2"))
	check(err)
	err = db.Put([]byte("k8"),[]byte("v8"))
	check(err)
	err = db.Put([]byte("k1"),[]byte("v11"))
	check(err)

	v,err :=  db.Get([]byte("k8"))
	fmt.Printf("%s \n",v)


	if !bytes.Equal(v,[]byte("v8")){
		t.Fatal()
	}
	v, err = db.Get([]byte("k1"))
	if !bytes.Equal(v,[]byte("v11")){
		t.Fatal()
	}


	db.Del([]byte("k1"))
	check(err)

	iter :=db.Iterator()
	for iter.Next(){
		fmt.Printf("%s - %s \n",string(iter.Key()),string(iter.Value()))
	}

}


func check(err error){

	if err !=nil{
		panic(err)
	}
}